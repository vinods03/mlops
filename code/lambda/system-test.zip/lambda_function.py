import boto3
import pandas as pd
import awswrangler as wr

sagemaker_client = boto3.client('sagemaker')
runtime_client = boto3.client('sagemaker-runtime')
s3_client = boto3.client('s3')

endpoint_name = 'diamond-price-predictor-endpoint'
bucket_name = 'data-us-west-2-100163808729'
test_features_key = 'feature-engg-output/test/test_features_all_records.csv'
test_data_key = 'feature-engg-output/test/test.csv'

s3_actuals_path = 's3://data-us-west-2-100163808729/system-test-output/actuals.csv'
s3_predictions_path = 's3://data-us-west-2-100163808729/system-test-output/predictions.csv'

def lambda_handler(event, context):

    print('**************** Predictions *****************')
    
    response = s3_client.get_object(Bucket = bucket_name, Key = test_features_key)
    test_features = response['Body'].read().decode('utf-8')

    try:
        response = runtime_client.invoke_endpoint(
            EndpointName = endpoint_name,
            ContentType = "text/csv",  # Specify the content type
            Body = test_features  # The input data as a CSV string
        )

        predictions = response['Body'].read().decode('utf-8')
        # print(type(predictions))
        # print(predictions)

        predictions_df = pd.DataFrame(list(map(lambda x: x.split(','), predictions.split(","))))
        print(type(predictions_df))
        print(predictions_df.head())
        wr.s3.to_csv(df = predictions_df, path = s3_predictions_path, index = False, header = False)
        # predictions_df.to_csv('predictions.csv', index=False, header=False)

    except Exception as e:
        print("Error invoking endpoint: ", e)

    print('**************** Actuals *****************')

    response = s3_client.get_object(Bucket = bucket_name, Key = test_data_key)
    actuals = response['Body'].read().decode('utf-8')
    # print(type(actuals))
    # print(actuals)

    actuals_df = pd.DataFrame(list(map(lambda x: x.split(','), actuals.split('\n'))))
    actuals_df = actuals_df.iloc[:, 0]
    print(actuals_df.head())
    wr.s3.to_csv(df = actuals_df, path = s3_actuals_path, index = False, header = False)
    # actual_results_df = actuals_df[actuals_df.columns[0]]
    # actual_results_df.to_csv('actuals.csv', index=False, header=False)
