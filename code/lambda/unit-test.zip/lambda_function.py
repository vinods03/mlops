import boto3
sagemaker_client = boto3.client('sagemaker')
runtime_client = boto3.client('sagemaker-runtime')
s3_client = boto3.client('s3')

endpoint_name = 'diamond-price-predictor-endpoint'
bucket_name = 'data-us-west-2-100163808729'
test_data_key = 'feature-engg-output/test/test_features_single_record.csv'

def lambda_handler(event, context):

    response = s3_client.get_object(Bucket=bucket_name, Key=test_data_key)
    test_data = response['Body'].read().decode('utf-8')
     
    try:
        response = runtime_client.invoke_endpoint(
            EndpointName=endpoint_name,
            ContentType="text/csv",  # Specify the content type
            Body=test_data  # The input data as a CSV string
        )
        result = response['Body'].read().decode('utf-8')
        print(result)
        return {
            'statusCode': 200,
            'body': result
        }

    except Exception as e:
        print("Error invoking endpoint: ", e)
        return {
            'statusCode': 500,
            'body': str(e)
        }

