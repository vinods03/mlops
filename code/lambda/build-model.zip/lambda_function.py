import json
import boto3
import time

def lambda_handler(event, context):
    sagemaker_client = boto3.client('sagemaker')

    # Define your SageMaker training job parameters
    # training_job_name = f"my-training-job-us-west-2-{context.aws_request_id}"
    sagemaker_role_arn = 'arn:aws:iam::100163808729:role/sagemaker-full-access-role'
    input_data_s3_uri = 's3://data-us-west-2-100163808729/feature-engg-output/train/train.csv'
    output_data_s3_uri = 's3://data-us-west-2-100163808729/training-output/output/'

    print('The context is: ', context)
    print('The event is: ', event)
    
    execution_id = event.get('execution_id')
    print('The execution_id is: ', execution_id)

    training_job_name = f"my-training-job-us-west-2-{execution_id}"

    try:
        response = sagemaker_client.create_training_job(
            TrainingJobName=training_job_name,
            AlgorithmSpecification={
                'TrainingImage': '433757028032.dkr.ecr.us-west-2.amazonaws.com/xgboost:latest',
                'TrainingInputMode': 'File'
            },
            RoleArn=sagemaker_role_arn,
            InputDataConfig=[
                {
                    'ChannelName': 'train',
                    'DataSource': {
                        'S3DataSource': {
                            'S3DataType': 'S3Prefix',
                            'S3Uri': input_data_s3_uri,
                            'S3DataDistributionType': 'FullyReplicated'
                        }
                    },
                    'ContentType': 'text/csv'
                }
            ],
            OutputDataConfig={
                'S3OutputPath': output_data_s3_uri
            },
            ResourceConfig={
                'InstanceType': 'ml.m5.xlarge',
                'InstanceCount': 1,
                'VolumeSizeInGB': 20
            },
            HyperParameters={
                'epochs':'10',
                'learning_rate':'0.01',
                'max_depth':'5',
                'eta':'0.2',
                'gamma':'4',
                'min_child_weight':'6',
                'subsample':'0.8',
                'silent':'0',
                'num_round':'100',
                'objective':'reg:linear',
                'eval_metric':'rmse',
                'seed':'42'
            },
            StoppingCondition={
                'MaxRuntimeInSeconds': 1800
            }
        )
        print(f"SageMaker training job started: {response['TrainingJobArn']}")
    except Exception as e:
        print(f"Error starting SageMaker training job: {e}")
        return {
            'statusCode': 500,
            'body': f"Error starting training job: {str(e)}"
        }

    try:
        describe_training_job_response = sagemaker_client.describe_training_job(TrainingJobName=training_job_name)
        while describe_training_job_response['TrainingJobStatus'] == 'InProgress':
            describe_training_job_response = sagemaker_client.describe_training_job(TrainingJobName=training_job_name)
            print(describe_training_job_response['TrainingJobStatus'])
            time.sleep(30)
        print("Training job completed! ", describe_training_job_response['TrainingJobStatus'])
    except Exception as e:
        print("Error describing SageMaker training job: ", e)
        