import tarfile
import boto3
import pickle as pkl
import time
from io import BytesIO

s3_client = boto3.client('s3')
sagemaker_client = boto3.client('sagemaker')

def lambda_handler(event, context):
    
    model_name = 'diamond-price-predictor-model'
    execution_role_arn = 'arn:aws:iam::100163808729:role/sagemaker-full-access-role' 
    image_uri = '433757028032.dkr.ecr.us-west-2.amazonaws.com/xgboost:latest' 

    # execution_id = event.get('execution_id')
    # print('The execution_id is: ', execution_id)
    print('The event is: ', event)
    best_tuning_job = event.get('body')
    model_uri = f's3://data-us-west-2-100163808729/tuning-output/{best_tuning_job}/output/model.tar.gz'

    endpoint_config_name = 'diamond-price-predictor-endpoint-config'
    endpoint_name = 'diamond-price-predictor-endpoint'
    instance_type = 'ml.m5.large' 
    initial_instance_count = 1

#   this will create a custom model in Sagemaker
    try:
        create_model_response = sagemaker_client.create_model(
            ModelName = model_name,
            PrimaryContainer = {
                'Image': image_uri,
                'ModelDataUrl': model_uri
            },
            ExecutionRoleArn = execution_role_arn
        )
        print("Model ARN: ", create_model_response['ModelArn'])
        describe_model_response = sagemaker_client.describe_model(ModelName = model_name)
        print("Model Description: ", describe_model_response)
    except Exception as e:
        print("Create model failed with exception ", e)
        

# using the above custom model, an endpoint config is created
    try:
        response = sagemaker_client.create_endpoint_config(
            EndpointConfigName = endpoint_config_name,
            ProductionVariants = [
                {
                    'VariantName': 'AllTraffic',
                    'ModelName': model_name,
                    'InitialInstanceCount': initial_instance_count,
                    'InstanceType': instance_type,
                }
            ]
        )
        print("Endpoint Config ARN: ", response['EndpointConfigArn'])
    except Exception as e:
        print("Create endpoint config failed with exception ", e)

# using the above endpoint config, endpoint is created
    try:
        create_endpoint_response = sagemaker_client.create_endpoint(
                        EndpointName = endpoint_name,
                        EndpointConfigName = endpoint_config_name
                    )
        print("Endpoint ARN: ", create_endpoint_response['EndpointArn'])
        describe_endpoint_response = sagemaker_client.describe_endpoint(EndpointName = endpoint_name)
        while describe_endpoint_response["EndpointStatus"] == "Creating":
            describe_endpoint_response = sagemaker_client.describe_endpoint(EndpointName=endpoint_name)
            print(describe_endpoint_response["EndpointStatus"])
            time.sleep(15)
        print("Endpoint created! ", describe_endpoint_response["EndpointStatus"])
    except Exception as e:
        print("Create endpoint failed with exception ", e)
    
    return {
        'statusCode': 200,
        'body': 'Model loaded and endpoint created successfully!'
    }