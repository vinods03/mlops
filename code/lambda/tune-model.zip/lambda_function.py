import boto3
import time

def lambda_handler(event, context):
    sagemaker_client = boto3.client('sagemaker')

    # Define your S3 paths
    s3_bucket = 'data-us-west-2-100163808729'
    input_data_uri = 's3://data-us-west-2-100163808729/feature-engg-output/train/'
    validation_data_uri = 's3://data-us-west-2-100163808729/feature-engg-output/validation/'
    output_data_uri = 's3://data-us-west-2-100163808729/tuning-output/'

    print('The context is: ', context)
    print('The event is: ', event)
    
    execution_id = event.get('execution_id')
    print('The execution_id is: ', execution_id)

    # need a substr because of length restrictions in tuning job name
    execution_id_for_tuning_jobname = execution_id.rsplit('-', 1)[0]
    print('The execution_id_for_tuning_jobname is: ', execution_id_for_tuning_jobname)

    tuning_job_name = f"tune-{execution_id_for_tuning_jobname}"

    # Define the hyperparameter tuning job configuration
    tuning_job_config = {
        'HyperParameterTuningJobName': tuning_job_name,
        'HyperParameterTuningJobConfig': {
            'Strategy': 'Random',
            'HyperParameterTuningJobObjective': {
                'MetricName': 'validation:rmse',
                'Type': 'Minimize'
            },
            'ParameterRanges': {
                'CategoricalParameterRanges': [],
                'ContinuousParameterRanges': [
                    {'Name': 'eta', 'MinValue': '0.01', 'MaxValue': '0.2'},
                    {'Name': 'gamma', 'MinValue': '0', 'MaxValue': '5'}
                ],
                'IntegerParameterRanges': [
                    {'Name': 'max_depth', 'MinValue': '3', 'MaxValue': '10'},
                    {'Name': 'min_child_weight', 'MinValue': '1', 'MaxValue': '10'},
                    {'Name': 'num_round', 'MinValue': '10', 'MaxValue': '100'}
                ]
            },
            'ResourceLimits': {
                'MaxNumberOfTrainingJobs': 3,
                'MaxParallelTrainingJobs': 3
            }
        },
        'TrainingJobDefinition': {
            'AlgorithmSpecification': {
                'TrainingImage': '433757028032.dkr.ecr.us-west-2.amazonaws.com/xgboost:latest', # e.g., '683313688378.dkr.ecr.us-east-1.amazonaws.com/sagemaker-xgboost:1.7-1'
                'TrainingInputMode': 'File'
            },
            'InputDataConfig': [
                {
                    'ChannelName': 'train',
                    'DataSource': {
                        'S3DataSource': {
                            'S3DataType': 'S3Prefix',
                            'S3Uri': input_data_uri,
                            'S3DataDistributionType': 'FullyReplicated'
                        }
                    },
                    'ContentType': 'text/csv' # Or appropriate content type
                },
                {
                    'ChannelName': 'validation',
                    'DataSource': {
                        'S3DataSource': {
                            'S3DataType': 'S3Prefix',
                            'S3Uri': validation_data_uri,
                            'S3DataDistributionType': 'FullyReplicated'
                        }
                    },
                    'ContentType': 'text/csv' # Or appropriate content type
                }
            ],
            'OutputDataConfig': {
                'S3OutputPath': output_data_uri
            },
            'ResourceConfig': {
                'InstanceType': 'ml.m5.xlarge',
                'InstanceCount': 1,
                'VolumeSizeInGB': 20
            },
            'RoleArn': 'arn:aws:iam::100163808729:role/sagemaker-full-access-role',
            'StoppingCondition': {
                'MaxRuntimeInSeconds': 3600
            }
        }
    }

    try:
        response = sagemaker_client.create_hyper_parameter_tuning_job(**tuning_job_config)
        print('The tuning job ', tuning_job_name, ' is created successfully')
    except Exception as e:
        print('The error in creating tuning job is: ', e)

    try:
        response = sagemaker_client.describe_hyper_parameter_tuning_job(HyperParameterTuningJobName = tuning_job_name)
        while response['HyperParameterTuningJobStatus'] == 'InProgress':
            response = sagemaker_client.describe_hyper_parameter_tuning_job(HyperParameterTuningJobName = tuning_job_name)
            print('The status of the tuning job is: ', response['HyperParameterTuningJobStatus'])
            time.sleep(30)
        print('The final response is: ', response)
        print('The status of the tuning job is: ', response['HyperParameterTuningJobStatus'])
        print('The best tuning job is: ', response['BestTrainingJob']['TrainingJobName'])
        return {
            'statusCode': 200,
            'body': response['BestTrainingJob']['TrainingJobName']
        }
    except Exception as e:
        print('The error in describe tuning job is: ', e)
