import json
import uuid

def lambda_handler(event, context):
    unique_id = str(uuid.uuid4())
    print(unique_id)

    return {
        'statusCode': 200,
        'execution_id': unique_id
    }
