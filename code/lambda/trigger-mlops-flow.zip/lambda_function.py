import json
import boto3
import time

sfn_client = boto3.client('stepfunctions')
state_machine_arn = 'arn:aws:states:us-west-2:100163808729:stateMachine:my-mlops-flow'

def lambda_handler(event, context):
    
    try:
        trigger_response = sfn_client.start_execution(stateMachineArn = state_machine_arn)
        print(f"Step Functions execution started: {trigger_response['executionArn']}")
        execution_arn = trigger_response['executionArn']
    except Exception as e:
        print("Error starting Step Functions execution: ", e)

    try:
        status_response = sfn_client.describe_execution(executionArn = execution_arn)
        while (status_response['status'] == 'RUNNING'):
            status_response = sfn_client.describe_execution(executionArn = execution_arn)
            print("Step Functions execution is still running: ", status_response['status'])
            time.sleep(15)
        print("Step Functions execution has completed: ", status_response['status'])
    except Exception as e:
        print("Error getting Step Functions execution status: ", e)

    return {
        'statusCode': 200,
        'body': json.dumps(status_response)
    }
